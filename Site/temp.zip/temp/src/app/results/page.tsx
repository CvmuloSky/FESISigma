// Results page - server component wrapper
import Results from './results-client';

export default function ResultsPage() {
  return <Results />;
}
